/*
 * Dispacth.cpp
 *
 *  Created on: 2018��7��3��
 *      Author: Xor
 */

#include <iostream>
using namespace std;

void __attribute__((weak)) TPLSayHello();

void DispatchSayHello(){
	TPLSayHello();
}

void DispatchSayHello2(){
	cout << "Hello again" << endl;
}
