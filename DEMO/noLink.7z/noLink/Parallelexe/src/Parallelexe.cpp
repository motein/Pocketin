/*
 * Parallelexe.cpp
 *
 *  Created on: 2018��7��3��
 *      Author: Xor
 */

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


void __attribute__((weak)) DispatchSayHello2();

void TPLSayHello2(){
	DispatchSayHello2();
}


void TPLSayHello(){
	cout << "Hello TPL again" << endl;
}
