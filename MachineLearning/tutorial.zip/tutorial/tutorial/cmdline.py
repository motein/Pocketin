'''
Created on 2015-8-28

@author: songhw
'''
import scrapy.cmdline

if __name__ == '__main__':
    scrapy.cmdline.execute(argv=['scrapy','crawl','dmoz'])